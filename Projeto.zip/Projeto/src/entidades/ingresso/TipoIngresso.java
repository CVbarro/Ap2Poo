package entidades.ingresso;

public enum TipoIngresso {
    INTEIRA, MEIA;
}
